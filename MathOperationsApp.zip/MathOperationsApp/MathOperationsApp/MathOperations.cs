﻿using System;

namespace MathOperationsApp
{
    // Define the MathOperations class
    public class MathOperations
    {
        // Method to double the input number
        public int Double(int number)
        {
            return number * 2;  // Returns the number multiplied by 2
        }

        // Method to square the input number
        public int Square(int number)
        {
            return number * number;  // Returns the number squared
        }

        // Method to subtract 10 from the input number
        public int SubtractTen(int number)
        {
            return number - 10;  // Returns the number minus 10
        }
    }
}
