﻿using System;

namespace MathOperationsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate the MathOperations class
            MathOperations operations = new MathOperations();

            // Ask the user for a number to perform math operations on
            Console.WriteLine("Enter a number to perform math operations on:");
            int userInput;

            // Validate the user input to ensure it's an integer
            while (!int.TryParse(Console.ReadLine(), out userInput))
            {
                Console.WriteLine("Please enter a valid integer.");
            }

            // Call the Double method and display the result
            int doubledResult = operations.Double(userInput);
            Console.WriteLine($"Double of {userInput} is: {doubledResult}");

            // Call the Square method and display the result
            int squaredResult = operations.Square(userInput);
            Console.WriteLine($"Square of {userInput} is: {squaredResult}");

            // Call the SubtractTen method and display the result
            int subtractedResult = operations.SubtractTen(userInput);
            Console.WriteLine($"{userInput} minus 10 is: {subtractedResult}");

            // Pause to allow the user to see the output before closing
            Console.ReadKey();
        }
    }
}
